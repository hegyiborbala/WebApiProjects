# Software Engineering projektek

**Kedves Hallgatók!**
Ebben a nyilvános repo-ban találhatóak meg a WebAPI fejlesztéshez kapcsolódó projektek. 
